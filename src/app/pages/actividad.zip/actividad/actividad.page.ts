import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, AlertController, ToastController } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { SesionService } from '../../services/sesion.service';
import { CloudinaryService, ArchivoSubido } from '../../services/cloudinary.service';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { environment } from 'src/environments/environment';

// ─── Tipos ──────────────────────────────────────────────────────────────────

export interface ActividadItem {
  id: number;
  titulo: string;
  instrucciones: string;
  tipo: string;
  fecha_entrega: string;
  valor_total: number;
  url_interactiva: string | null;
  asignatura: string;
  asignatura_id: number;
  grupo: string;
  grupo_id: number;
  docente: string;
  publicada: boolean;
  vencida: boolean;
  totalEntregas?: number;
  totalAlumnos?: number;
  entrega: {
    calificacion: number | null;
    feedback: string;
    entregada_en: string;
  } | null;
}

interface Materia  { id: number; nombre: string; }
interface Grupo    { id: number; nombre: string; grado: number; aula: string; }
interface ArchivoEnProgreso {
  file: File; progreso: number; subiendo: boolean; error: boolean; resultado?: ArchivoSubido;
}

const TIPOS_ACTIVIDAD = [
  { value: 'ABIERTA',     label: 'Pregunta abierta',      icon: 'create-outline' },
  { value: 'MULTIPLE',    label: 'Opción múltiple',        icon: 'list-outline' },
  { value: 'ARCHIVO',     label: 'Subir archivo',          icon: 'cloud-upload-outline' },
  { value: 'INTERACTIVA', label: 'Ejercicio interactivo',  icon: 'game-controller-outline' },
];

const MAX_MB  = 20;
const EXT_BAN = ['exe','bat','sh','cmd','msi'];

// ─────────────────────────────────────────────────────────────────────────────

@Component({
  standalone: true,
  selector: 'app-actividad',
  templateUrl: './actividad.page.html',
  styleUrls: ['./actividad.page.scss'],
  imports: [CommonModule, FormsModule, IonicModule, RouterModule],
})
export class ActividadPage implements OnInit {

  private supabase: SupabaseClient;

  // ── Estado general ───────────────────────────────────────────
  cargando = true;
  error    = '';

  // ── Lista y filtros (alumno y docente) ───────────────────────
  actividades: ActividadItem[] = [];
  filtro: 'TODAS' | 'PENDIENTE' | 'ENTREGADA' | 'CALIFICADA' = 'TODAS';

  // ── Formulario (solo docente) ────────────────────────────────
  showForm      = false;
  editingId: number | null = null;
  guardando     = false;
  isDragging    = false;

  tiposActividad = TIPOS_ACTIVIDAD;

  newAct = {
    titulo:        '',
    instrucciones: '',
    tipo:          'ABIERTA' as string,
    fecha:         '',
    hora:          '23:59',
    valor_total:   10,
    url_interactiva: '',
    publicada:     true,
    materiaId:     null as number | null,
    grupoId:       null as number | null,
  };

  archivosEnProgreso: ArchivoEnProgreso[] = [];
  archivosExistentes: ArchivoSubido[]     = [];

  // ── Opciones selector materia/grupo ─────────────────────────
  materias:        Materia[] = [];
  gruposDeMateria: Grupo[]   = [];
  cargandoOpts    = false;
  errorOpts: string | null = null;

  readonly fechaMinima = new Date().toISOString().split('T')[0];

  get esAlumno():  boolean { return this.sesion.esAlumno(); }
  get esDocente(): boolean { return this.sesion.esDocente(); }

  constructor(
    private sesion:     SesionService,
    private cloudinary: CloudinaryService,
    private alertCtrl: AlertController,
    private toastCtrl: ToastController,
  ) {
    this.supabase = createClient(environment.supabaseUrl, environment.supabaseKey, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
    });
  }

  ngOnInit() {
    if (this.esDocente) this.cargarMaterias();
    this.cargarActividades();
  }

  // ══════════════════════════════════════════════════════════
  //  CARGA DE DATOS
  // ══════════════════════════════════════════════════════════

  async cargarActividades() {
    this.cargando = true;
    this.error    = '';
    try {
      if (this.esAlumno)       await this.cargarParaAlumno();
      else if (this.esDocente) await this.cargarParaDocente();
    } catch (e: any) {
      this.error = 'Error al cargar actividades: ' + e.message;
    }
    this.cargando = false;
  }

  async cargarParaAlumno() {
    const alumnoId = this.sesion.usuario?.id;
    if (!alumnoId) return;

    const { data: usu } = await this.supabase
      .from('users_user').select('alumno_grupo_id').eq('id', alumnoId).single();
    const grupoId = (usu as any)?.alumno_grupo_id;
    if (!grupoId) return;

    const { data: acts, error } = await this.supabase
      .from('academic_actividad')
      .select('id, titulo, instrucciones, tipo, fecha_entrega, valor_total, url_interactiva, asignatura_id, grupo_id')
      .eq('grupo_id', grupoId).eq('publicada', true)
      .order('fecha_entrega', { ascending: true });
    if (error) throw error;

    // Asignaturas y docentes
    const asiIds = [...new Set((acts || []).map((a: any) => a.asignatura_id))];
    let asiNombres: Record<number, string> = {};
    if (asiIds.length) {
      const { data: asis } = await this.supabase.from('academic_asignatura').select('id, nombre').in('id', asiIds);
      (asis || []).forEach((a: any) => { asiNombres[a.id] = a.nombre; });
    }

    const { data: entregas } = await this.supabase
      .from('academic_entregaactividad').select('actividad_id, calificacion, feedback, entregada_en')
      .eq('alumno_id', alumnoId);
    const entMap: Record<number, any> = {};
    (entregas || []).forEach((e: any) => { entMap[e.actividad_id] = e; });

    const ahora = new Date();
    this.actividades = (acts || []).map((a: any) => ({
      id: a.id, titulo: a.titulo, instrucciones: a.instrucciones || '',
      tipo: a.tipo, fecha_entrega: a.fecha_entrega,
      valor_total: parseFloat(a.valor_total),
      url_interactiva: a.url_interactiva,
      asignatura: asiNombres[a.asignatura_id] || '—',
      asignatura_id: a.asignatura_id, grupo: '', grupo_id: a.grupo_id,
      docente: '', publicada: true,
      vencida: new Date(a.fecha_entrega) < ahora,
      entrega: entMap[a.id] ? {
        calificacion: entMap[a.id].calificacion != null ? parseFloat(entMap[a.id].calificacion) : null,
        feedback:     entMap[a.id].feedback || '',
        entregada_en: entMap[a.id].entregada_en,
      } : null,
    }));
  }

  async cargarParaDocente() {
    const docenteId = this.sesion.usuario?.id;
    if (!docenteId) return;

    const { data: acts, error } = await this.supabase
      .from('academic_actividad')
      .select('id, titulo, instrucciones, tipo, fecha_entrega, valor_total, url_interactiva, publicada, asignatura_id, grupo_id')
      .eq('docente_id', docenteId)
      .order('fecha_entrega', { ascending: false });
    if (error) throw error;

    const asiIds  = [...new Set((acts || []).map((a: any) => a.asignatura_id))];
    const gruIds  = [...new Set((acts || []).map((a: any) => a.grupo_id))];

    let asiNombres: Record<number, string> = {};
    let gruNombres: Record<number, string> = {};

    if (asiIds.length) {
      const { data: asis } = await this.supabase.from('academic_asignatura').select('id, nombre').in('id', asiIds);
      (asis || []).forEach((a: any) => { asiNombres[a.id] = a.nombre; });
    }
    if (gruIds.length) {
      const { data: grus } = await this.supabase.from('academic_grupo').select('id, nombre, grado').in('id', gruIds);
      (grus || []).forEach((g: any) => { gruNombres[g.id] = `${g.grado}° ${g.nombre}`; });
    }

    const ahora = new Date();
    this.actividades = (acts || []).map((a: any) => ({
      id: a.id, titulo: a.titulo, instrucciones: a.instrucciones || '',
      tipo: a.tipo, fecha_entrega: a.fecha_entrega,
      valor_total: parseFloat(a.valor_total),
      url_interactiva: a.url_interactiva,
      asignatura: asiNombres[a.asignatura_id] || '—', asignatura_id: a.asignatura_id,
      grupo: gruNombres[a.grupo_id] || '—', grupo_id: a.grupo_id,
      docente: '', publicada: a.publicada,
      vencida: new Date(a.fecha_entrega) < ahora,
      entrega: null,
    }));

    // Conteo de entregas (no crítico)
    try {
      const ids = this.actividades.map(a => a.id);
      const { data: entregas } = await this.supabase
        .from('academic_entregaactividad').select('actividad_id').in('actividad_id', ids);
      const conteo: Record<number, number> = {};
      (entregas || []).forEach((e: any) => { conteo[e.actividad_id] = (conteo[e.actividad_id] || 0) + 1; });

      const { count } = await this.supabase
        .from('users_user').select('*', { count: 'exact', head: true })
        .in('alumno_grupo_id', gruIds as number[]).eq('rol', 'ALUMNO');

      this.actividades = this.actividades.map(a => ({
        ...a, totalEntregas: conteo[a.id] || 0, totalAlumnos: count || 0
      }));
    } catch {}
  }

  // ══════════════════════════════════════════════════════════
  //  MATERIAS Y GRUPOS (docente)
  // ══════════════════════════════════════════════════════════

  async cargarMaterias() {
    const uid = this.sesion.usuario?.id;
    if (!uid) return;
    this.cargandoOpts = true;
    try {
      const { data: rel } = await this.supabase
        .from('academic_asignatura_docentes').select('asignatura_id').eq('user_id', uid);
      const ids = [...new Set((rel || []).map((r: any) => r.asignatura_id))];
      if (!ids.length) return;
      const { data } = await this.supabase.from('academic_asignatura').select('id, nombre').in('id', ids).order('nombre');
      this.materias = data || [];
    } finally { this.cargandoOpts = false; }
  }

  async onMateriaChange(preservarGrupo: number | null = null) {
    if (!preservarGrupo) this.newAct.grupoId = null;
    this.gruposDeMateria = [];
    if (!this.newAct.materiaId) return;

    this.cargandoOpts = true;
    this.errorOpts = null;
    try {
      const uid = this.sesion.usuario?.id;
      const { data: relGM } = await this.supabase
        .from('academic_asignatura_grupos').select('grupo_id').eq('asignatura_id', this.newAct.materiaId);
      const idsGM = (relGM || []).map((r: any) => r.grupo_id);
      if (!idsGM.length) return;

      const { data: relDG } = await this.supabase
        .from('academic_grupo_docentes').select('grupo_id').eq('user_id', uid).in('grupo_id', idsGM);
      const idsFinal = (relDG || []).map((r: any) => r.grupo_id);
      if (!idsFinal.length) return;

      const { data } = await this.supabase
        .from('academic_grupo').select('id, nombre, grado, aula').in('id', idsFinal).order('grado').order('nombre');
      this.gruposDeMateria = data || [];

      if (preservarGrupo && this.gruposDeMateria.some(g => g.id === preservarGrupo))
        this.newAct.grupoId = preservarGrupo;
    } catch (e: any) {
      this.errorOpts = `No se pudieron cargar los grupos: ${e.message}`;
    } finally { this.cargandoOpts = false; }
  }

  // ══════════════════════════════════════════════════════════
  //  FORMULARIO — ABRIR / CERRAR
  // ══════════════════════════════════════════════════════════

  abrirFormularioNuevo() {
    this.editingId = null;
    this.resetForm();
    this.showForm = true;
  }

  async abrirFormularioEditar(a: ActividadItem) {
    this.editingId = a.id;
    this.archivosEnProgreso = [];
    this.archivosExistentes = [];
    const fechaHora = a.fecha_entrega?.slice(0, 16) || '';
    this.newAct = {
      titulo:          a.titulo,
      instrucciones:   a.instrucciones,
      tipo:            a.tipo,
      fecha:           fechaHora.slice(0, 10),
      hora:            fechaHora.slice(11, 16) || '23:59',
      valor_total:     a.valor_total,
      url_interactiva: a.url_interactiva || '',
      publicada:       a.publicada,
      materiaId:       a.asignatura_id,
      grupoId:         null,
    };
    this.showForm = true;
    await this.onMateriaChange(a.grupo_id);
  }

  async solicitarCierre() {
    const a = await this.alertCtrl.create({
      header: 'Descartar cambios',
      message: '¿Salir sin guardar?',
      buttons: [
        { text: 'Seguir editando', role: 'cancel' },
        { text: 'Descartar', role: 'destructive', handler: () => this.forzarCierre() },
      ],
    });
    await a.present();
  }

  forzarCierre() { this.showForm = false; this.editingId = null; this.resetForm(); }

  private resetForm() {
    this.newAct = {
      titulo: '', instrucciones: '', tipo: 'ABIERTA', fecha: '', hora: '23:59',
      valor_total: 10, url_interactiva: '', publicada: true, materiaId: null, grupoId: null,
    };
    this.archivosEnProgreso = [];
    this.archivosExistentes = [];
    this.gruposDeMateria    = [];
    this.errorOpts          = null;
  }

  // ══════════════════════════════════════════════════════════
  //  GUARDAR ACTIVIDAD
  // ══════════════════════════════════════════════════════════

  async guardarActividad() {
    const f = this.newAct;
    if (!f.titulo.trim())   { this.toast('Ponle un título.',           'warning'); return; }
    if (!f.materiaId)       { this.toast('Elige la materia.',          'warning'); return; }
    if (!f.grupoId)         { this.toast('Elige el grupo.',            'warning'); return; }
    if (!f.fecha)           { this.toast('Elige la fecha de entrega.', 'warning'); return; }
    if (f.tipo === 'INTERACTIVA' && !f.url_interactiva?.trim())
      { this.toast('Agrega el enlace de la actividad interactiva.', 'warning'); return; }
    if (this.archivosEnProgreso.some(a => a.subiendo))
      { this.toast('Espera a que terminen de subirse los archivos.', 'warning'); return; }

    this.guardando = true;
    try {
      const archivos = this.archivosEnProgreso.filter(a => a.resultado).map(a => a.resultado!);
      const archivoFinal = archivos.length ? archivos[0] : this.archivosExistentes[0] || null;

      const payload: any = {
        titulo:          f.titulo.trim(),
        instrucciones:   f.instrucciones.trim(),
        tipo:            f.tipo,
        fecha_entrega:   `${f.fecha}T${f.hora}:00`,
        valor_total:     f.valor_total,
        url_interactiva: f.url_interactiva?.trim() || null,
        publicada:       f.publicada,
        asignatura_id:   f.materiaId,
        grupo_id:        f.grupoId,
        docente_id:      this.sesion.usuario?.id,
        archivo:         archivoFinal ? archivoFinal.url : null,
      };

      if (this.editingId) {
        const { data, error } = await this.supabase.from('academic_actividad')
          .update(payload).eq('id', this.editingId).select().single();
        if (error) throw error;
        const idx = this.actividades.findIndex(a => a.id === this.editingId);
        if (idx !== -1) {
          const g = this.gruposDeMateria.find(g => g.id === f.grupoId);
          const m = this.materias.find(m => m.id === f.materiaId);
          this.actividades[idx] = {
            ...this.actividades[idx],
            titulo: data.titulo, instrucciones: data.instrucciones, tipo: data.tipo,
            fecha_entrega: data.fecha_entrega, valor_total: parseFloat(data.valor_total),
            url_interactiva: data.url_interactiva, publicada: data.publicada,
            asignatura: m?.nombre || this.actividades[idx].asignatura,
            grupo: g ? `${g.grado}° ${g.nombre}` : this.actividades[idx].grupo,
          };
        }
        this.toast('Actividad actualizada.', 'success');
      } else {
        const { data, error } = await this.supabase.from('academic_actividad')
          .insert(payload).select().single();
        if (error) throw error;

        const g = this.gruposDeMateria.find(g => g.id === f.grupoId);
        const m = this.materias.find(m => m.id === f.materiaId);
        const ahora = new Date();
        this.actividades.unshift({
          id: data.id, titulo: data.titulo, instrucciones: data.instrucciones,
          tipo: data.tipo, fecha_entrega: data.fecha_entrega,
          valor_total: parseFloat(data.valor_total),
          url_interactiva: data.url_interactiva,
          asignatura: m?.nombre || '—', asignatura_id: f.materiaId!,
          grupo: g ? `${g.grado}° ${g.nombre}` : '—', grupo_id: f.grupoId!,
          docente: '', publicada: data.publicada,
          vencida: new Date(data.fecha_entrega) < ahora,
          totalEntregas: 0, totalAlumnos: 0, entrega: null,
        });
        this.toast('Actividad creada.', 'success');
      }

      this.forzarCierre();
    } catch (e: any) {
      this.toast(`Error: ${e.message}`, 'danger');
    } finally { this.guardando = false; }
  }

  // ── Eliminar ──────────────────────────────────────────────
  async eliminarActividad(act: ActividadItem) {
    const a = await this.alertCtrl.create({
      header: 'Eliminar actividad',
      message: `¿Eliminar "${act.titulo}"? Esta acción no se puede deshacer.`,
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Eliminar', role: 'destructive',
          handler: async () => {
            const { error } = await this.supabase.from('academic_actividad').delete().eq('id', act.id);
            if (error) { this.toast('No se pudo eliminar.', 'danger'); return; }
            this.actividades = this.actividades.filter(a => a.id !== act.id);
            this.toast('Actividad eliminada.', 'success');
          }
        }
      ]
    });
    await a.present();
  }

  // ── Publicar / despublicar ────────────────────────────────
  async togglePublicada(act: ActividadItem, ev: Event) {
    ev.stopPropagation();
    const { error } = await this.supabase.from('academic_actividad')
      .update({ publicada: !act.publicada }).eq('id', act.id);
    if (error) { this.toast('No se pudo cambiar el estado.', 'danger'); return; }
    act.publicada = !act.publicada;
    this.toast(act.publicada ? 'Actividad publicada.' : 'Guardada como borrador.', 'success');
  }

  // ══════════════════════════════════════════════════════════
  //  ARCHIVOS
  // ══════════════════════════════════════════════════════════

  onDragOver(e: DragEvent)  { e.preventDefault(); e.stopPropagation(); this.isDragging = true; }
  onDragLeave(e: DragEvent) { e.preventDefault(); e.stopPropagation(); this.isDragging = false; }
  onDrop(e: DragEvent) {
    e.preventDefault(); e.stopPropagation(); this.isDragging = false;
    if (e.dataTransfer?.files.length) this.subirArchivos(Array.from(e.dataTransfer.files));
  }
  onFilesSelected(e: any) {
    if (e.target.files?.length) { this.subirArchivos(Array.from(e.target.files)); e.target.value = ''; }
  }

  private subirArchivos(files: File[]) {
    for (const file of files) {
      const err = this.validarArchivo(file);
      if (err) { this.toast(`"${file.name}": ${err}`, 'warning'); continue; }
      const item: ArchivoEnProgreso = { file, progreso: 0, subiendo: true, error: false };
      this.archivosEnProgreso.push(item);
      this.cloudinary.subirArchivo(file, pct => item.progreso = pct)
        .then(r => { item.subiendo = false; item.resultado = r; })
        .catch(() => { item.subiendo = false; item.error = true; });
    }
  }

  private validarArchivo(file: File): string | null {
    if (file.size / 1048576 > MAX_MB) return `Supera ${MAX_MB}MB.`;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (EXT_BAN.includes(ext)) return 'Tipo no permitido.';
    return null;
  }

  removeFile(i: number, e: Event) { e.stopPropagation(); this.archivosEnProgreso.splice(i, 1); }
  removeArchivoExistente(i: number, e: Event) { e.stopPropagation(); this.archivosExistentes.splice(i, 1); }

  reintentarArchivo(i: number, e: Event) {
    e.stopPropagation();
    const item = this.archivosEnProgreso[i];
    item.error = false; item.subiendo = true; item.progreso = 0;
    this.cloudinary.subirArchivo(item.file, pct => item.progreso = pct)
      .then(r => { item.subiendo = false; item.resultado = r; })
      .catch(() => { item.subiendo = false; item.error = true; });
  }

  // ══════════════════════════════════════════════════════════
  //  FILTROS y HELPERS
  // ══════════════════════════════════════════════════════════

  get actividadesFiltradas(): ActividadItem[] {
    if (this.filtro === 'PENDIENTE')  return this.actividades.filter(a => !a.entrega);
    if (this.filtro === 'ENTREGADA')  return this.actividades.filter(a => a.entrega && a.entrega.calificacion == null);
    if (this.filtro === 'CALIFICADA') return this.actividades.filter(a => a.entrega?.calificacion != null);
    return this.actividades;
  }

  get totalPendientes():  number { return this.actividades.filter(a => !a.entrega).length; }
  get totalEntregadas():  number { return this.actividades.filter(a => a.entrega && a.entrega.calificacion == null).length; }
  get totalCalificadas(): number { return this.actividades.filter(a => a.entrega?.calificacion != null).length; }

  get completionPercent(): number {
    if (!this.actividades.length) return 0;
    return Math.round(((this.totalEntregadas + this.totalCalificadas) / this.actividades.length) * 100);
  }
  get progressOffset(): number { return 2 * Math.PI * 50 * (1 - this.completionPercent / 100); }

  getEstadoClass(a: ActividadItem): string {
    if (!a.entrega) return a.vencida ? 'no-entregada' : 'pendiente';
    return a.entrega.calificacion != null ? 'calificada' : 'entregada';
  }
  getEstadoLabel(a: ActividadItem): string {
    if (!a.entrega) return a.vencida ? 'No entregada' : 'Pendiente';
    return a.entrega.calificacion != null ? 'Calificada' : 'Entregada';
  }
  getEstadoIcon(a: ActividadItem): string {
    if (!a.entrega) return a.vencida ? 'close-circle-outline' : 'time-outline';
    return a.entrega.calificacion != null ? 'ribbon-outline' : 'checkmark-circle-outline';
  }
  getTipoIcon(tipo: string): string {
    return { ABIERTA:'create-outline', MULTIPLE:'list-outline', ARCHIVO:'cloud-upload-outline', INTERACTIVA:'game-controller-outline' }[tipo] || 'clipboard-outline';
  }
  getTipoLabel(tipo: string): string {
    return { ABIERTA:'Pregunta abierta', MULTIPLE:'Opción múltiple', ARCHIVO:'Subir archivo', INTERACTIVA:'Ejercicio interactivo' }[tipo] || tipo;
  }
  colorNota(n: number): string {
    if (n >= 9) return 'excelente'; if (n >= 7) return 'bien'; if (n >= 6) return 'regular'; return 'reprobado';
  }
  esCritica(a: ActividadItem): boolean {
    if (a.entrega) return false;
    const diff = (new Date(a.fecha_entrega).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return diff <= 2 && diff >= 0;
  }
  formatFecha(f: string): string {
    return new Date(f).toLocaleDateString('es-MX', { day:'numeric', month:'short', year:'numeric' });
  }
  diasRestantes(f: string): string {
    const diff = Math.ceil((new Date(f).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    if (diff < 0) return `Venció hace ${Math.abs(diff)} día${Math.abs(diff) !== 1 ? 's':''}`;
    if (diff === 0) return 'Vence hoy';
    if (diff === 1) return 'Vence mañana';
    return `${diff} días restantes`;
  }
  getFileIcon(name: string): string {
    const ext = name.split('.').pop()?.toLowerCase();
    return { pdf:'document-text-outline', doc:'reader-outline', docx:'reader-outline', jpg:'image-outline', jpeg:'image-outline', png:'image-outline', mp4:'videocam-outline', mov:'videocam-outline', zip:'archive-outline' }[ext||''] || 'document-outline';
  }
  formatSize(b: number): string {
    if (!b) return '0 B';
    const k = 1024, s = ['B','KB','MB'], i = Math.floor(Math.log(b)/Math.log(k));
    return (b/Math.pow(k,i)).toFixed(1)+' '+s[i];
  }

  doRefresh(event: any) { this.cargarActividades().then(() => event.target.complete()); }

  private async toast(msg: string, color: string) {
    const t = await this.toastCtrl.create({ message: msg, duration: 2500, color, position: 'bottom' });
    await t.present();
  }
}
