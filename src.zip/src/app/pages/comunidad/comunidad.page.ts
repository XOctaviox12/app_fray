import { Component, OnInit } from '@angular/core';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { environment } from 'src/environments/environment';
import { SesionService } from '../../services/sesion.service';

export interface Comunicado {
  id: number;
  titulo: string;
  cuerpo: string;
  destinatario: string;
  creado_en: string;
  activo: boolean;
  adjunto: string | null;
  autor: {
    id: number;
    first_name: string;
    last_name: string;
    rol: string;
  };
  grupo: { id: number; nombre: string } | null;
}

@Component({
  standalone: false,
  selector: 'app-comunidad',
  templateUrl: './comunidad.page.html',
  styleUrls: ['./comunidad.page.scss'],
})
export class ComunidadPage implements OnInit {

  private supabase: SupabaseClient;

  // ── Rol actual ───────────────────────────
  get esTutor():   boolean { return this.sesion.esTutor(); }
  get esDocente(): boolean { return this.sesion.esDocente(); }
  get esAlumno():  boolean { return this.sesion.esAlumno(); }

  // ── Comunicados ──────────────────────────
  comunicadosMaestros:   Comunicado[] = [];
  comunicadosDireccion:  Comunicado[] = [];
  cargando = true;
  error = '';

  // ── Nuevo comunicado (docente/director) ──
  nuevoTitulo  = '';
  nuevoCuerpo  = '';
  adjuntoFile: File | null = null;
  adjuntoNombre = '';
  publicando   = false;
  errorPublicar = '';

  // ── Pestaña activa (solo tutor) ──────────
  tabActiva: 'maestros' | 'direccion' = 'maestros';

  constructor(private sesion: SesionService) {
    this.supabase = createClient(environment.supabaseUrl, environment.supabaseKey, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
    });
  }

  ngOnInit() {
    this.cargarComunicados();
  }

  async cargarComunicados() {
    this.cargando = true;
    this.error = '';

    try {
      const plantelId = this.sesion.usuario?.plantel_id
        || await this.getPlantelDeTutor();

      if (!plantelId) {
        this.error = 'No se encontró el plantel.';
        this.cargando = false;
        return;
      }

      // Traer comunicados activos del plantel, solo los que NO son para alumnos
      // Destinatario TODOS = toda la comunidad, DOCENTES = solo staff
      // Desde la app móvil mostramos:
      //   - Tutores: ven TODOS (no DOCENTES)
      //   - Docentes: ven TODOS y DOCENTES
      //   - Alumnos: ven TODOS

      let query = this.supabase
        .from('academic_comunicado')
        .select(`
          id, titulo, cuerpo, destinatario, creado_en, activo, adjunto,
          autor:autor_id ( id, first_name, last_name, rol ),
          grupo:grupo_id ( id, nombre )
        `)
        .eq('plantel_id', plantelId)
        .eq('activo', true)
        .order('creado_en', { ascending: false });

      // Tutores y alumnos solo ven los de destinatario TODOS
      if (this.esTutor || this.esAlumno) {
        query = query.eq('destinatario', 'TODOS');
      }

      const { data, error } = await query;
      if (error) throw new Error(error.message);

      const todos = (data || []) as any[];

      // Separar por rol del autor
      this.comunicadosMaestros  = todos.filter(c => c.autor?.rol === 'DOCENTE');
      this.comunicadosDireccion = todos.filter(c =>
        ['DIRECTOR', 'COORD', 'ADMIN'].includes(c.autor?.rol)
      );

    } catch (e: any) {
      this.error = 'Error al cargar comunicados: ' + e.message;
    }

    this.cargando = false;
  }

  async getPlantelDeTutor(): Promise<number | null> {
    const alumnoId = this.sesion.tutor?.alumno_id;
    if (!alumnoId) return null;
    const { data } = await this.supabase
      .from('users_user')
      .select('plantel_id')
      .eq('id', alumnoId)
      .single();
    return (data as any)?.plantel_id || null;
  }

  // ── Subir adjunto ────────────────────────
  onAdjuntoChange(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    this.adjuntoFile  = file;
    this.adjuntoNombre = file.name;
  }

  quitarAdjunto() {
    this.adjuntoFile   = null;
    this.adjuntoNombre = '';
  }

  // ── Publicar comunicado ──────────────────
  async publicarComunicado() {
    if (!this.nuevoTitulo.trim() || !this.nuevoCuerpo.trim()) {
      this.errorPublicar = 'El título y el mensaje son obligatorios.';
      return;
    }

    this.publicando   = true;
    this.errorPublicar = '';

    try {
      const autorId   = this.sesion.usuario!.id;
      const plantelId = this.sesion.usuario!.plantel_id;
      let adjuntoUrl: string | null = null;

      // Subir adjunto a Supabase Storage si existe
      if (this.adjuntoFile) {
        const ext      = this.adjuntoFile.name.split('.').pop();
        const fileName = `comunicados/${Date.now()}.${ext}`;
        const { error: upErr } = await this.supabase.storage
          .from('adjuntos')
          .upload(fileName, this.adjuntoFile);
        if (!upErr) {
          const { data: urlData } = this.supabase.storage
            .from('adjuntos')
            .getPublicUrl(fileName);
          adjuntoUrl = urlData.publicUrl;
        }
      }

      const { error } = await this.supabase
        .from('academic_comunicado')
        .insert({
          titulo:       this.nuevoTitulo.trim(),
          cuerpo:       this.nuevoCuerpo.trim(),
          destinatario: 'TODOS',
          plantel_id:   plantelId,
          autor_id:     autorId,
          adjunto:      adjuntoUrl,
          activo:       true,
        });

      if (error) throw new Error(error.message);

      // Limpiar form y recargar
      this.nuevoTitulo   = '';
      this.nuevoCuerpo   = '';
      this.adjuntoFile   = null;
      this.adjuntoNombre = '';
      await this.cargarComunicados();

    } catch (e: any) {
      this.errorPublicar = 'Error al publicar: ' + e.message;
    }

    this.publicando = false;
  }

  // ── Helpers ──────────────────────────────
  getInitials(c: Comunicado): string {
    const n = `${c.autor?.first_name || ''} ${c.autor?.last_name || ''}`.trim();
    const parts = n.split(' ');
    return parts.length >= 2
      ? (parts[0][0] + parts[1][0]).toUpperCase()
      : (parts[0]?.[0] || '?').toUpperCase();
  }

  getNombreAutor(c: Comunicado): string {
    return `${c.autor?.first_name || ''} ${c.autor?.last_name || ''}`.trim() || 'Desconocido';
  }

  getRolLabel(c: Comunicado): string {
    const map: Record<string, string> = {
      DOCENTE: 'Docente', DIRECTOR: 'Dirección',
      COORD: 'Coordinación', ADMIN: 'Administración'
    };
    return map[c.autor?.rol] || c.autor?.rol || '';
  }

  esDirectivo(c: Comunicado): boolean {
    return ['DIRECTOR', 'COORD', 'ADMIN'].includes(c.autor?.rol);
  }

  formatFecha(fecha: string): string {
    const d   = new Date(fecha);
    const now = new Date();
    const diffMs  = now.getTime() - d.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1)   return 'Justo ahora';
    if (diffMin < 60)  return `Hace ${diffMin} min`;
    const diffH = Math.floor(diffMin / 60);
    if (diffH < 24)    return `Hace ${diffH}h`;
    const diffD = Math.floor(diffH / 24);
    if (diffD < 7)     return `Hace ${diffD} días`;
    return d.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' });
  }

  doRefresh(event: any) {
    this.cargarComunicados().then(() => event.target.complete());
  }

  triggerFileInput() {
    document.getElementById('adjuntoInput')?.click();
  }
}