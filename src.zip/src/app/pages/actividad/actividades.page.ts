import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonList,
  IonItem, IonLabel, IonBadge, IonSkeletonText, IonRefresher,
  IonRefresherContent, IonSegment, IonSegmentButton, IonIcon
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { starOutline, timeOutline } from 'ionicons/icons';
import { SupabaseService } from '../../services/supabase';

@Component({
  selector: 'app-actividades',
  templateUrl: './actividades.page.html',
  standalone: true,
  imports: [
    CommonModule, IonHeader, IonToolbar, IonTitle, IonContent,
    IonList, IonItem, IonLabel, IonBadge, IonSkeletonText,
    IonRefresher, IonRefresherContent, IonSegment, IonSegmentButton, IonIcon
  ],
})
export class ActividadesPage implements OnInit {
  actividades: any[] = [];
  filtradas: any[] = [];
  segmento = 'activas';
  cargando = true;
  esDocente = false;
  hoy = new Date();

  constructor(private supabase: SupabaseService) {
    this.esDocente = this.supabase.usuario?.rol === 'DOCENTE';
    addIcons({ starOutline, timeOutline });
  }

  async ngOnInit() { await this.cargar(); }

  async cargar(event?: any) {
    this.cargando = true;
    this.hoy = new Date();
    try {
      this.actividades = await this.supabase.getActividades() || [];
      this.filtrar();
    } finally {
      this.cargando = false;
      event?.target?.complete();
    }
  }

  filtrar() {
    const ahora = this.hoy;
    if (this.segmento === 'activas') {
      this.filtradas = this.actividades.filter(a =>
        a.publicada && new Date(a.fecha_entrega) >= ahora
      );
    } else if (this.segmento === 'vencidas') {
      this.filtradas = this.actividades.filter(a =>
        a.publicada && new Date(a.fecha_entrega) < ahora
      );
    } else {
      this.filtradas = this.actividades.filter(a => !a.publicada);
    }
  }

  cambiarSegmento(ev: any) {
    this.segmento = ev.detail.value;
    this.filtrar();
  }
}
