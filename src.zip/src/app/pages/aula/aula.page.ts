import { Component, OnInit } from '@angular/core';
import { SesionService } from '../../services/sesion.service';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { environment } from 'src/environments/environment';

@Component({
  standalone: false,
  selector: 'app-aula',
  templateUrl: './aula.page.html',
  styleUrls: ['./aula.page.scss'],
})
export class AulaPage implements OnInit {

  grupos: any[]    = [];
  cargando         = false;
  error: string | null = null;

  // Solo tutor
  nombreHijo  = '';
  grupoHijo: any = null;

  private supabase: SupabaseClient;

  constructor(public sesion: SesionService) {
    this.supabase = createClient(environment.supabaseUrl, environment.supabaseKey, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
    });
  }

  ngOnInit() { this.cargarDatos(); }

  async cargarDatos() {
    this.cargando = true;
    this.error    = null;

    try {
      if (this.sesion.esTutor()) {
        await this.cargarDatosTutor();
      } else if (this.sesion.esDocente()) {
        await this.cargarGruposDocente();
      } else {
        await this.cargarGrupoAlumno();
      }
    } catch (err: any) {
      console.error('AulaPage error:', err.message);
      this.error = 'No se pudieron cargar los datos. Intenta de nuevo.';
    } finally {
      this.cargando = false;
    }
  }

  // ── Docente: grupos via M2M academic_grupo_docentes ──────────────
  private async cargarGruposDocente() {
    const docenteId = this.sesion.usuario?.id;
    if (!docenteId) return;

    // Paso 1: obtener IDs de grupo del docente
    const { data: rel, error: e1 } = await this.supabase
      .from('academic_grupo_docentes')
      .select('grupo_id')
      .eq('user_id', docenteId);

    if (e1) throw e1;
    if (!rel || rel.length === 0) { this.grupos = []; return; }

    const grupoIds = rel.map((r: any) => r.grupo_id);

    // Paso 2: obtener info completa de esos grupos
    const { data: grupos, error: e2 } = await this.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .in('id', grupoIds)
      .order('grado');

    if (e2) throw e2;
    this.grupos = grupos || [];
  }

  // ── Alumno: su único grupo via users_user.alumno_grupo_id ─────────
  private async cargarGrupoAlumno() {
    const alumnoId = this.sesion.usuario?.id;
    if (!alumnoId) return;

    const { data: usu, error: e1 } = await this.supabase
      .from('users_user')
      .select('alumno_grupo_id')
      .eq('id', alumnoId)
      .single();

    if (e1) throw e1;
    const grupoId = (usu as any)?.alumno_grupo_id;
    if (!grupoId) { this.grupos = []; return; }

    const { data: grupo, error: e2 } = await this.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .eq('id', grupoId)
      .single();

    if (e2) throw e2;
    this.grupos = grupo ? [grupo] : [];
  }

  // ── Tutor: grupo del hijo vinculado ───────────────────────────────
  private async cargarDatosTutor() {
    const alumnoId = this.sesion.tutor?.alumno_id;
    if (!alumnoId) return;

    // Datos del hijo
    const { data: alumno, error: e1 } = await this.supabase
      .from('users_user')
      .select('first_name, last_name, alumno_grupo_id')
      .eq('id', alumnoId)
      .single();

    if (e1) throw e1;
    if (!alumno) return;

    this.nombreHijo = `${(alumno as any).first_name} ${(alumno as any).last_name}`.trim();

    const grupoId = (alumno as any).alumno_grupo_id;
    if (!grupoId) { this.grupoHijo = null; return; }

    const { data: grupo, error: e2 } = await this.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .eq('id', grupoId)
      .single();

    if (e2) throw e2;
    this.grupoHijo = grupo || null;
  }

  get esTutor():  boolean { return this.sesion.esTutor(); }
  get esDocente(): boolean { return this.sesion.esDocente(); }
}