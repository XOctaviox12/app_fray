import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SesionService, Usuario } from './services/sesion.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent implements OnInit {

  constructor(private router: Router, private sesion: SesionService) {}

  ngOnInit() {
    // La sesion local ya se carga dentro del constructor de SesionService.
  }

  get usuario(): Usuario | null {
    return this.sesion.usuario;
  }

  get loggedIn(): boolean {
    return this.sesion.loggedIn;
  }

  get avatarUrl(): string {
    return this.sesion.getAvatarUrl();
  }

  // ── Helpers de rol para el menú dinámico ───────────────────────────
  get esAlumno(): boolean {
    return this.sesion.rolActual === 'ALUMNO';
  }

  get esDocente(): boolean {
    return ['DOCENTE', 'COORD', 'DIRECTOR'].includes(this.sesion.rolActual);
  }

  get esTutor(): boolean {
    return this.sesion.rolActual === 'TUTOR';
  }

  getNombreDisplay(): string {
    return this.sesion.getNombreDisplay();
  }

  getEmailDisplay(): string {
    if (this.sesion.tutor) return this.sesion.tutor.parentesco;
    return this.sesion.usuario?.email || '';
  }

  onErrorImagen() {
    // El getter avatarUrl ya recalcula el default si no hay foto_perfil.
  }

  cerrarSesion() {
    this.sesion.cerrarSesion();
    this.router.navigate(['/login']);
  }

  /** Se mantiene este metodo porque login.page.ts lo invoca tal cual. */
  async iniciarSesion(username: string, password: string): Promise<boolean> {
    return this.sesion.iniciarSesion(username, password);
  }
}