import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { SesionService } from '../../../services/sesion.service';

interface MetricaAsistencia {
  total: number;
  presentes: number;
  ausentes: number;
  retardos: number;
  porcentaje: number;
}

@Component({
  standalone: false,
  selector: 'app-detalle',
  templateUrl: './detalle.page.html',
  styleUrls: ['./detalle.page.scss'],
})
export class DetallePage implements OnInit {
  grupoId!: number;
  grupo: any = null;
  cargando = false;
  error: string | null = null;

  // Métricas
  asistencia: MetricaAsistencia = { total: 0, presentes: 0, ausentes: 0, retardos: 0, porcentaje: 0 };
  totalAlumnos  = 0;
  totalMaterias = 0;
  totalTareas   = 0;
  tareasEntregadas = 0;

  // Desglose por materia (asistencia)
  materias: { nombre: string; porcentaje: number; color: string }[] = [];

  get porcentajeColor(): string {
    if (this.asistencia.porcentaje >= 85) return 'verde';
    if (this.asistencia.porcentaje >= 70) return 'naranja';
    return 'rojo';
  }

  get porcentajeEntregas(): number {
    if (!this.totalTareas) return 0;
    return Math.round((this.tareasEntregadas / this.totalTareas) * 100);
  }

  constructor(
    private route: ActivatedRoute,
    private navCtrl: NavController,
    private sesion: SesionService
  ) {}

  ngOnInit() {
    this.grupoId = Number(this.route.snapshot.paramMap.get('id'));
    this.cargarTodo();
  }

  volver() { this.navCtrl.back(); }

  async cargarTodo() {
    this.cargando = true;
    this.error    = null;
    try {
      await Promise.all([
        this.cargarGrupo(),
        this.cargarAsistencia(),
        this.cargarAlumnos(),
        this.cargarTareas(),
      ]);
    } catch (err: any) {
      console.error('Detalle error:', err.message);
      this.error = 'No se pudieron cargar las métricas.';
    } finally {
      this.cargando = false;
    }
  }

  private async cargarGrupo() {
    const { data, error } = await this.sesion.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .eq('id', this.grupoId)
      .single();
    if (error) throw error;
    this.grupo = data;
  }

  private async cargarAsistencia() {
    // Consulta todos los registros de asistencia del grupo.
    // academic_asistencia.estado: 'P' = Presente, 'A' = Ausente, 'R' = Retardo
    // TODO(schema): confirmar que la tabla se llama academic_asistencia y
    // que la columna de grupo se llama grupo_id. Ajustar si difiere.
    const { data, error } = await this.sesion.supabase
      .from('academic_asistencia')
      .select('estado')
      .eq('grupo_id', this.grupoId);

    if (error) throw error;
    if (!data?.length) return;

    const total     = data.length;
    const presentes = data.filter((r: any) => r.estado === 'P').length;
    const ausentes  = data.filter((r: any) => r.estado === 'A').length;
    const retardos  = data.filter((r: any) => r.estado === 'R').length;

    this.asistencia = {
      total,
      presentes,
      ausentes,
      retardos,
      porcentaje: Math.round(((presentes + retardos * 0.5) / total) * 100),
    };
  }

  private async cargarAlumnos() {
    // Cuenta cuántos alumnos pertenecen a este grupo
    // TODO(schema): confirmar columna. Puede ser alumno_grupo_id en users_user
    const { count, error } = await this.sesion.supabase
      .from('users_user')
      .select('id', { count: 'exact', head: true })
      .eq('alumno_grupo_id', this.grupoId);

    if (error) throw error;
    this.totalAlumnos = count ?? 0;
  }

  private async cargarTareas() {
    // Total de tareas asignadas al grupo y cuántas han sido entregadas
    // TODO(schema): confirmar tabla de tareas y columnas de grupo/estado
    const { data: tareas, error: e1 } = await this.sesion.supabase
      .from('academic_tarea')
      .select('id')
      .eq('grupo_id', this.grupoId);

    if (e1) throw e1;
    this.totalTareas = tareas?.length ?? 0;
    if (!this.totalTareas) return;

    const ids = tareas!.map((t: any) => t.id);
    const { count, error: e2 } = await this.sesion.supabase
      .from('academic_entrega')
      .select('id', { count: 'exact', head: true })
      .in('tarea_id', ids);

    if (e2) throw e2;
    this.tareasEntregadas = count ?? 0;
  }
}
