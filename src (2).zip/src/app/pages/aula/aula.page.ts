import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SesionService } from '../../services/sesion.service';

@Component({
  standalone: false,
  selector: 'app-aula',
  templateUrl: './aula.page.html',
  styleUrls: ['./aula.page.scss'],
})
export class AulaPage implements OnInit {
  grupos: any[]  = [];
  grupoHijo: any = null;
  nombreHijo     = '';
  cargando       = false;
  error: string | null = null;

  get esDocente(): boolean { return this.sesion.esDocente(); }
  get esAlumno():  boolean { return this.sesion.esAlumno(); }
  get esTutor():   boolean { return this.sesion.esTutor(); }

  constructor(private sesion: SesionService, private router: Router) {}

  ngOnInit() { this.cargarDatos(); }

  verDetalle(grupoId: number) {
    this.router.navigate(['/aula/detalle', grupoId]);
  }

  async cargarDatos() {
    const usuario = this.sesion.usuario;
    if (!usuario) { this.error = 'No hay sesión activa.'; return; }
    this.cargando = true;
    this.error    = null;
    try {
      if (this.esTutor)       await this.cargarDatosTutor(usuario.id);
      else if (this.esDocente) await this.cargarGruposDocente(usuario.id);
      else                     await this.cargarGrupoAlumno(usuario.id);
    } catch (err: any) {
      console.error('AulaPage error:', err.message);
      this.error = 'No se pudieron cargar los datos. Intenta de nuevo.';
    } finally {
      this.cargando = false;
    }
  }

  private async cargarGruposDocente(docenteId: number) {
    const { data: rel, error: e1 } = await this.sesion.supabase
      .from('academic_grupo_docentes')
      .select('grupo_id')
      .eq('user_id', docenteId);
    if (e1) throw e1;
    if (!rel?.length) { this.grupos = []; return; }

    const { data, error: e2 } = await this.sesion.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .in('id', rel.map((r: any) => r.grupo_id))
      .order('grado');
    if (e2) throw e2;
    this.grupos = data || [];
  }

  private async cargarGrupoAlumno(alumnoId: number) {
    const { data: usu, error: e1 } = await this.sesion.supabase
      .from('users_user')
      .select('alumno_grupo_id')
      .eq('id', alumnoId)
      .single();
    if (e1) throw e1;
    const grupoId = (usu as any)?.alumno_grupo_id;
    if (!grupoId) { this.grupos = []; return; }

    const { data, error: e2 } = await this.sesion.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .eq('id', grupoId)
      .single();
    if (e2) throw e2;
    this.grupos = data ? [data] : [];
  }

  private async cargarDatosTutor(tutorId: number) {
    // TODO(schema): confirmar tabla de relación tutor↔alumno
    const { data: rel, error: e1 } = await this.sesion.supabase
      .from('tutor_tutorado')
      .select('alumno_id')
      .eq('tutor_id', tutorId)
      .single();
    if (e1) throw e1;
    const alumnoId = (rel as any)?.alumno_id;
    if (!alumnoId) return;

    const { data: alumno, error: e2 } = await this.sesion.supabase
      .from('users_user')
      .select('first_name, last_name, alumno_grupo_id')
      .eq('id', alumnoId)
      .single();
    if (e2) throw e2;
    if (!alumno) return;

    this.nombreHijo = `${(alumno as any).first_name} ${(alumno as any).last_name}`.trim();
    const grupoId = (alumno as any).alumno_grupo_id;
    if (!grupoId) return;

    const { data: grupo, error: e3 } = await this.sesion.supabase
      .from('academic_grupo')
      .select('id, nombre, grado, aula, capacidad_maxima, plantel_id')
      .eq('id', grupoId)
      .single();
    if (e3) throw e3;
    this.grupoHijo = grupo || null;
  }
}
