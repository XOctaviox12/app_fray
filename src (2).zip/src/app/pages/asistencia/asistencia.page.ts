import { Component, OnInit } from '@angular/core';
import { NavController, ToastController, AlertController } from '@ionic/angular';
import { SesionService } from '../../services/sesion.service';

type Estado = 'P' | 'A' | 'R';

interface Alumno {
  id: number;
  numero: number; // posición fija en la lista, no cambia al filtrar
  nombre: string;
  apellido: string;
  foto: string | null;
  estado: Estado;
  guardado: boolean; // true si ya hay registro en la fecha seleccionada
  revisado: boolean; // true si el maestro ya tocó algún botón para este alumno
}

interface GrupoResumen {
  id: number;
  nombre: string;
  totalAlumnos: number;
  tomada: boolean; // ya se tomó lista en la fecha seleccionada
}

const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const MESES_LARGO = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
];
const MESES_CORTO = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

@Component({
  standalone: false,
  selector: 'app-asistencia',
  templateUrl: './asistencia.page.html',
  styleUrls: ['./asistencia.page.scss'],
})
export class AsistenciaPage implements OnInit {

  // ── Vista general ──────────────────────────────────────────
  // 'selector' = eligiendo grupo · 'tomar' = pasando lista / viendo historial
  vista: 'selector' | 'tomar' = 'selector';

  // ── Selector de grupo ───────────────────────────────────────
  grupos: GrupoResumen[] = [];
  cargandoGrupos = false;
  errorGrupos: string | null = null;

  // ── Grupo activo ────────────────────────────────────────────
  grupoId!: number;
  grupoNombre = '';

  // ── Fecha seleccionada para tomar/editar asistencia ─────────
  // Por defecto hoy. El maestro puede elegir una fecha pasada para
  // capturar o corregir listas atrasadas; no se permiten fechas futuras.
  fechaSeleccionada = new Date();
  mostrarSelectorFecha = false;

  alumnos: Alumno[] = [];
  filtroAlumno = '';
  private snapshotEstados: Map<number, Estado> = new Map(); // para detectar cambios sin guardar

  cargando = false;
  guardando = false;
  error: string | null = null;
  yaGuardada = false; // lista de la fecha seleccionada ya existe

  // Segmento activo dentro de 'tomar'
  segmento: 'lista' | 'historial' = 'lista';

  // Historial
  historial: { fecha: string; presentes: number; ausentes: number; retardos: number; total: number }[] = [];
  cargandoHistorial = false;

  get totalPresentes(): number { return this.alumnos.filter(a => a.estado === 'P').length; }
  get totalAusentes():  number { return this.alumnos.filter(a => a.estado === 'A').length; }
  get totalRetardos():  number { return this.alumnos.filter(a => a.estado === 'R').length; }
  get totalSinRevisar(): number { return this.alumnos.filter(a => !a.revisado).length; }
  get porcentaje():     number {
    if (!this.alumnos.length) return 0;
    return Math.round(((this.totalPresentes + this.totalRetardos * 0.5) / this.alumnos.length) * 100);
  }

  get alumnosFiltrados(): Alumno[] {
    const q = this.filtroAlumno.trim().toLowerCase();
    if (!q) return this.alumnos;
    return this.alumnos.filter(a =>
      `${a.nombre} ${a.apellido}`.toLowerCase().includes(q)
    );
  }

  get hayComosGuardar(): boolean {
    if (!this.alumnos.length) return false;
    return this.alumnos.some(a => this.snapshotEstados.get(a.id) !== a.estado);
  }

  // ── Fecha: helpers de UI ─────────────────────────────────────
  get hoyISO(): string {
    return this.toDateStr(new Date());
  }

  get fechaSeleccionadaISO(): string {
    return this.toDateStr(this.fechaSeleccionada);
  }

  get esHoy(): boolean {
    return this.fechaSeleccionadaISO === this.hoyISO;
  }

  get fechaSeleccionadaDisplay(): string {
    const dia = DIAS[this.fechaSeleccionada.getDay()];
    const mes = MESES_LARGO[this.fechaSeleccionada.getMonth()];
    return `${dia} ${this.fechaSeleccionada.getDate()} de ${mes}`;
  }

  constructor(
    private navCtrl: NavController,
    private toastCtrl: ToastController,
    private alertCtrl: AlertController,
    private sesion: SesionService
  ) {}

  ngOnInit() {
    this.cargarGrupos();
  }

  // ═══════════════════════════════════════════════════════════
  // SELECTOR DE GRUPO
  // ═══════════════════════════════════════════════════════════

  async cargarGrupos() {
    if (!this.sesion.esDocente()) {
      this.errorGrupos = 'Esta sección es solo para maestros.';
      return;
    }

    this.cargandoGrupos = true;
    this.errorGrupos = null;

    try {
      const docenteId = this.sesion.usuario!.id;

      // 1. Grupos del maestro — relación M:N vía academic_grupo_docentes
      //    (confirmado en Supabase: columnas grupo_id, user_id)
      const { data: relaciones, error: eRel } = await this.sesion.supabase
        .from('academic_grupo_docentes')
        .select('grupo_id')
        .eq('user_id', docenteId);
      if (eRel) throw eRel;

      const ids = [...new Set((relaciones || []).map((r: any) => r.grupo_id))];

      if (ids.length === 0) {
        this.grupos = [];
        return;
      }

      // 2. Datos de esos grupos
      const { data: gruposData, error: eGrupos } = await this.sesion.supabase
        .from('academic_grupo')
        .select('id, nombre')
        .in('id', ids)
        .order('nombre');
      if (eGrupos) throw eGrupos;

      // 3. Cantidad de alumnos por grupo (una sola consulta)
      // TODO(schema): confirmar columna real de FK alumno→grupo (alumno_grupo_id)
      const { data: alumnosData } = await this.sesion.supabase
        .from('users_user')
        .select('id, alumno_grupo_id')
        .in('alumno_grupo_id', ids);

      const conteoPorGrupo = new Map<number, number>();
      (alumnosData || []).forEach((a: any) => {
        conteoPorGrupo.set(a.alumno_grupo_id, (conteoPorGrupo.get(a.alumno_grupo_id) || 0) + 1);
      });

      // 4. Qué grupos ya tienen lista tomada en la fecha seleccionada
      const fechaStr = this.toDateStr(this.fechaSeleccionada);
      const { data: asistFecha } = await this.sesion.supabase
        .from('academic_asistencia')
        .select('grupo_id')
        .in('grupo_id', ids)
        .eq('fecha', fechaStr);

      const gruposConLista = new Set((asistFecha || []).map((a: any) => a.grupo_id));

      this.grupos = (gruposData || []).map((g: any) => ({
        id: g.id,
        nombre: g.nombre,
        totalAlumnos: conteoPorGrupo.get(g.id) || 0,
        tomada: gruposConLista.has(g.id),
      }));

    } catch (err: any) {
      console.error('Error cargando grupos:', err.message);
      // DIAGNÓSTICO TEMPORAL: mostramos el error real de Supabase para identificar
      // si es RLS, columna inexistente, o tabla inexistente. Quitar después.
      this.errorGrupos = `No se pudieron cargar tus grupos. Detalle: ${err.message || err}`;
    } finally {
      this.cargandoGrupos = false;
    }
  }

  seleccionarGrupo(grupo: GrupoResumen) {
    this.grupoId = grupo.id;
    this.grupoNombre = grupo.nombre;
    this.vista = 'tomar';
    this.segmento = 'lista';
    this.cargarAlumnos();
  }

  // ── Cambiar la fecha seleccionada (protege cambios sin guardar) ──
  private parseISO(iso: string): Date {
    const [y, m, d] = iso.split('T')[0].split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  async onFechaChange(valor: string | string[] | null | undefined) {
    const valorISO = Array.isArray(valor) ? valor[0] : valor;
    if (!valorISO) { this.mostrarSelectorFecha = false; return; }
    const nuevaFecha = this.parseISO(valorISO);

    if (this.toDateStr(nuevaFecha) === this.fechaSeleccionadaISO) {
      this.mostrarSelectorFecha = false;
      return;
    }
    this.mostrarSelectorFecha = false;
    await this.cambiarFecha(nuevaFecha);
  }

  irAHoy() {
    if (this.esHoy) return;
    this.cambiarFecha(new Date());
  }

  // Tocar un día del historial: brinca directo a "Tomar lista" en esa fecha
  abrirDiaHistorial(fechaISO: string) {
    this.cambiarFecha(this.parseISO(fechaISO), /* forzarSegmentoLista */ true);
  }

  private async cambiarFecha(nuevaFecha: Date, forzarSegmentoLista = false) {
    const aplicarCambio = async () => {
      this.fechaSeleccionada = nuevaFecha;
      if (forzarSegmentoLista) this.segmento = 'lista';
      if (this.vista === 'selector') {
        await this.cargarGrupos();
      } else {
        await this.cargarAlumnos();
      }
    };

    // this.hayComosGuardar refleja el estado de this.alumnos sin importar
    // qué pestaña (lista/historial) esté activa en este momento — así se
    // protege igual si el cambio de fecha viene desde el historial.
    if (this.vista === 'tomar' && this.hayComosGuardar) {
      const alert = await this.alertCtrl.create({
        header: 'Cambios sin guardar',
        message: 'Cambiar de fecha descartará los cambios sin guardar de la lista actual. ¿Deseas continuar?',
        cssClass: 'asist-alert',
        buttons: [
          { text: 'Cancelar', role: 'cancel' },
          { text: 'Cambiar de todas formas', role: 'destructive', handler: aplicarCambio },
        ],
      });
      await alert.present();
      return;
    }

    await aplicarCambio();
  }

  // ── Pull-to-refresh ───────────────────────────────────────────
  async onRefresh(event: any) {
    try {
      if (this.vista === 'selector') {
        await this.cargarGrupos();
      } else if (this.segmento === 'historial') {
        this.historial = [];
        await this.cargarHistorial();
      } else {
        await this.cargarAlumnos();
      }
    } finally {
      event?.target?.complete();
    }
  }

  // ── Volver (con protección de cambios sin guardar) ──────────
  async volver() {
    if (this.vista === 'tomar') {
      if (this.segmento === 'lista' && this.hayComosGuardar) {
        const alert = await this.alertCtrl.create({
          header: 'Cambios sin guardar',
          message: 'Tienes cambios en la lista que no has guardado. ¿Deseas salir de todas formas?',
          cssClass: 'asist-alert',
          buttons: [
            { text: 'Seguir editando', role: 'cancel' },
            { text: 'Salir sin guardar', role: 'destructive', handler: () => this.irASelector() },
          ],
        });
        await alert.present();
        return;
      }
      this.irASelector();
      return;
    }
    // Ya estamos en el selector: salir de la página
    this.navCtrl.back();
  }

  private irASelector() {
    this.vista = 'selector';
    this.alumnos = [];
    this.historial = [];
    this.error = null;
    this.cargarGrupos(); // refresca estados "tomada" para la fecha seleccionada
  }

  // ═══════════════════════════════════════════════════════════
  // TOMAR LISTA
  // ═══════════════════════════════════════════════════════════

  async cargarAlumnos() {
    this.cargando = true;
    this.error = null;
    try {
      // Verificación de pertenencia: el grupo debe ser del maestro en sesión
      // (relación M:N vía academic_grupo_docentes, no una columna directa).
      const { data: grupo, error: eGrupo } = await this.sesion.supabase
        .from('academic_grupo')
        .select('id, nombre')
        .eq('id', this.grupoId)
        .single();
      if (eGrupo || !grupo) throw eGrupo || new Error('Grupo no encontrado');

      const { data: relacion, error: eRel } = await this.sesion.supabase
        .from('academic_grupo_docentes')
        .select('id')
        .eq('grupo_id', this.grupoId)
        .eq('user_id', this.sesion.usuario?.id)
        .maybeSingle();
      if (eRel) throw eRel;

      if (!relacion) {
        this.error = 'No tienes permiso para tomar asistencia en este grupo.';
        this.cargando = false;
        return;
      }
      this.grupoNombre = grupo.nombre;

      // Alumnos del grupo
      const { data: users, error: e1 } = await this.sesion.supabase
        .from('users_user')
        .select('id, first_name, last_name, foto_perfil')
        .eq('alumno_grupo_id', this.grupoId)
        .order('last_name');
      if (e1) throw e1;

      // Asistencia registrada para la fecha seleccionada
      const fechaStr = this.toDateStr(this.fechaSeleccionada);
      const { data: asist } = await this.sesion.supabase
        .from('academic_asistencia')
        .select('alumno_id, estado')
        .eq('grupo_id', this.grupoId)
        .eq('fecha', fechaStr);

      const asistMap = new Map((asist || []).map((a: any) => [a.alumno_id, a.estado]));
      this.yaGuardada = asistMap.size > 0;

      this.alumnos = (users || []).map((u: any, i: number) => ({
        id:       u.id,
        numero:   i + 1,
        nombre:   u.first_name || '',
        apellido: u.last_name || '',
        foto:     u.foto_perfil,
        estado:   (asistMap.get(u.id) as Estado) ?? 'P', // default: Presente
        guardado: asistMap.has(u.id),
        // "revisado": si ya había un registro guardado antes, se considera
        // que ya fue revisado en su momento. Si es la primera vez que se
        // carga (sin registro), empieza sin revisar hasta que el maestro
        // toque explícitamente algún botón P/R/A.
        revisado: asistMap.has(u.id),
      }));

      this.filtroAlumno = '';

      // snapshot para detectar cambios sin guardar
      this.snapshotEstados = new Map(this.alumnos.map(a => [a.id, a.estado]));

    } catch (err: any) {
      console.error('Error cargando alumnos:', err.message);
      this.error = 'No se pudo cargar la lista. Verifica tu conexión.';
    } finally {
      this.cargando = false;
    }
  }

  iniciales(alumno: Alumno): string {
    const n = alumno.nombre?.charAt(0) || '';
    const a = alumno.apellido?.charAt(0) || '';
    return (n + a).toUpperCase() || '?';
  }

  // ── Cambiar estado de un alumno ──────────────────────────────
  setEstado(alumno: Alumno, estado: Estado) {
    alumno.estado = estado;
    alumno.revisado = true;
  }

  // ── Acciones globales (con confirmación para evitar toques accidentales) ──
  async confirmarMarcarTodos(estado: Estado) {
    if (!this.alumnos.length) return;

    const etiqueta = estado === 'P' ? 'presentes' : estado === 'A' ? 'ausentes' : 'con retardo';
    const alert = await this.alertCtrl.create({
      header: 'Confirmar acción',
      message: `Vas a marcar a los ${this.alumnos.length} alumnos como ${etiqueta}. ¿Continuar?`,
      cssClass: 'asist-alert',
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        { text: 'Sí, marcar a todos', handler: () => this.marcarTodos(estado) },
      ],
    });
    await alert.present();
  }

  private marcarTodos(estado: Estado) {
    this.alumnos.forEach(a => { a.estado = estado; a.revisado = true; });
  }

  // ── Guardar lista ────────────────────────────────────────────
  async guardarLista() {
    if (!this.alumnos.length || this.guardando) return;

    // 1) Si la fecha seleccionada NO es hoy, confirmar primero: es el error
    //    más fácil de cometer al permitir elegir fecha (guardar en el día
    //    equivocado sin darse cuenta).
    if (!this.esHoy) {
      const alert = await this.alertCtrl.create({
        header: 'Fecha distinta a hoy',
        message: `Vas a guardar la asistencia del ${this.fechaSeleccionadaDisplay}, no la de hoy. ¿Es correcto?`,
        cssClass: 'asist-alert',
        buttons: [
          { text: 'Cancelar', role: 'cancel' },
          { text: 'Sí, es correcto', handler: () => this.confirmarSobrescrituraYGuardar() },
        ],
      });
      await alert.present();
      return;
    }

    await this.confirmarSobrescrituraYGuardar();
  }

  // 2) Aviso si ya existía una lista guardada en esa fecha (evita sobrescribir por error)
  private async confirmarSobrescrituraYGuardar() {
    if (this.yaGuardada) {
      const alert = await this.alertCtrl.create({
        header: 'Lista ya registrada',
        message: `Ya existe una lista guardada el ${this.fechaSeleccionadaDisplay} para este grupo. ¿Deseas sobrescribirla con los cambios actuales?`,
        cssClass: 'asist-alert',
        buttons: [
          { text: 'Cancelar', role: 'cancel' },
          { text: 'Sobrescribir', handler: () => this.confirmarResumenYGuardar() },
        ],
      });
      await alert.present();
      return;
    }

    await this.confirmarResumenYGuardar();
  }

  // 3) Resumen final — siempre se muestra antes de guardar, con avisos
  //    adicionales si hay ausentismo alto o alumnos sin revisar.
  private async confirmarResumenYGuardar() {
    const pctAusentes = this.alumnos.length
      ? Math.round((this.totalAusentes / this.alumnos.length) * 100)
      : 0;

    let mensaje =
      `<strong>${this.grupoNombre}</strong> · ${this.fechaSeleccionadaDisplay}<br>` +
      `${this.totalPresentes} presentes · ${this.totalRetardos} retardos · ${this.totalAusentes} ausentes`;

    if (pctAusentes >= 30) {
      mensaje += `<br><br>⚠️ ${pctAusentes}% de ausentismo, verifica antes de guardar.`;
    }
    if (this.totalSinRevisar > 0) {
      mensaje += `<br><br>⚠️ ${this.totalSinRevisar} alumno(s) sin revisar (quedaron en "Presente" por defecto).`;
    }

    const alert = await this.alertCtrl.create({
      header: 'Confirmar asistencia',
      message: mensaje,
      cssClass: 'asist-alert',
      buttons: [
        { text: 'Revisar de nuevo', role: 'cancel' },
        { text: 'Guardar', handler: () => this.ejecutarGuardado() },
      ],
    });
    await alert.present();
  }

  private async ejecutarGuardado() {
    this.guardando = true;

    const fechaStr  = this.toDateStr(this.fechaSeleccionada);
    const docenteId = this.sesion.usuario?.id;

    const registros = this.alumnos.map(a => ({
      alumno_id:  a.id,
      grupo_id:   this.grupoId,
      docente_id: docenteId,
      fecha:      fechaStr,
      estado:     a.estado,
    }));

    // TODO(schema): confirmar PK compuesta de academic_asistencia para el upsert
    const { error } = await this.sesion.supabase
      .from('academic_asistencia')
      .upsert(registros, { onConflict: 'alumno_id,grupo_id,fecha' });

    this.guardando = false;

    if (error) {
      this.mostrarToast('Error al guardar. Intenta de nuevo.', 'danger');
      console.error(error.message);
      return;
    }

    this.alumnos.forEach(a => { a.guardado = true; a.revisado = true; });
    this.snapshotEstados = new Map(this.alumnos.map(a => [a.id, a.estado]));
    this.yaGuardada = true;
    this.mostrarToast(`Lista guardada · ${this.totalPresentes}P ${this.totalRetardos}R ${this.totalAusentes}A`, 'success');
  }

  // ── Historial ────────────────────────────────────────────────
  async onSegmentoChange() {
    if (this.segmento === 'historial' && !this.historial.length) {
      await this.cargarHistorial();
    }
  }

  async cargarHistorial() {
    this.cargandoHistorial = true;
    const { data, error } = await this.sesion.supabase
      .from('academic_asistencia')
      .select('fecha, estado')
      .eq('grupo_id', this.grupoId)
      .order('fecha', { ascending: false });

    if (!error && data) {
      const porFecha = new Map<string, { P: number; A: number; R: number }>();
      data.forEach((r: any) => {
        if (!porFecha.has(r.fecha)) porFecha.set(r.fecha, { P: 0, A: 0, R: 0 });
        const d = porFecha.get(r.fecha)!;
        d[r.estado as Estado]++;
      });

      this.historial = Array.from(porFecha.entries()).map(([fecha, cnt]) => ({
        fecha,
        presentes: cnt.P,
        retardos:  cnt.R,
        ausentes:  cnt.A,
        total:     cnt.P + cnt.A + cnt.R,
      }));
    }
    this.cargandoHistorial = false;
  }

  formatFecha(iso: string): string {
    const [y, m, d] = iso.split('-');
    return `${d} ${MESES_CORTO[+m - 1]} ${y}`;
  }

  porcentajeHistorial(item: any): number {
    if (!item.total) return 0;
    return Math.round(((item.presentes + item.retardos * 0.5) / item.total) * 100);
  }

  private toDateStr(d: Date): string {
    return d.toISOString().split('T')[0];
  }

  private async mostrarToast(msg: string, color: string) {
    const t = await this.toastCtrl.create({
      message: msg, duration: 2500, color,
      position: 'bottom', cssClass: 'asist-toast'
    });
    await t.present();
  }
}
